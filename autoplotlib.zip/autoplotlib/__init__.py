"""autoplotlib - quickly generate plots in Python by simply describing them through text."""

__version__ = "0.1.1"

from autoplotlib.main import plot
